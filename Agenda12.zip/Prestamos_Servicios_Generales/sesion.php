<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="assets/img/icono_membretado.png" type="image/x-icon" >
    <title>SERVICIOS GENERALES</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Custom CSS -->
    <link href="assets/css/styles_sesion.css" rel="stylesheet">	
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css"
      rel="stylesheet"
    />
	
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	
	<!-- DataTables CSS -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	
	<!-- FullCalendar CSS -->
	<link href="assets/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	
 <!-- jQuery -->
 <script src="assets/js/jquery.js"></script>	
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
  <script src="assets/js/isotope.pkgd.min.js"></script> 
 
  <meta name="theme-color" content="#7952b3">
<style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

<link href="assets/css/signin.css" rel="stylesheet">
    
  </head>

  <body>
    

  <div class="intro-header img-responsive">
    <div class="container">

      <div class="row">
        <div class="col-lg-7">
          <div class="intro-message">
            <h1 style="color:white;"><i class=""  aria-hidden="true"></i> Servicios Generales</h1>
            <h3 style="color:white;">Préstamos de vehiculos</h3>
            <hr class="intro-divider">
            <div class="form-group">
          </div>                       
          </div>

        </div>
      
        

        <main class="form-signin">
<form>
<!--<img class="mb-4" src="/docs/5.1/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57">
<h1 class="h3 mb-3 fw-normal">Por favor ingresa</h1>
<button  title="Solo para encargados de área"><i class="fa-solid fa-circle-info"></i></button>-->
<div class="form-floating">
<input type="text" class="form-control" id="floatingInput" name="nombre_usuario" placeholder="Usuario">
<label style="color:black;" for="floatingInput">Usuario</label>
</div>
<div class="form-floating">
<input type="password" class="form-control" id="floatingPassword" name="contra" placeholder="Contraseña">
<label style="color:black;" for="floatingPassword">Contraseña</label>
</div>
<!--<div class="checkbox mb-3">
<label>
<input type="checkbox" value="remember-me"> Recuérdame
</label>
</div>-->
<button class="w-100 btn btn-lg btn-primary" type="submit">Ingresar</button>
<!--<p class="mt-5 mb-3 text-muted">&copy; 2017–2023</p>-->
</form>
</main>
      </div>
    </div>
    <!-- /.container -->
   
  </div>

 
  </body>

  </html>