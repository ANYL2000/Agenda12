<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="assets/img/icono_membretado.png" type="image/x-icon" >
    <title>SERVICIOS GENERALES</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Custom CSS -->
    <link href="assets/css/styles_sesion.css" rel="stylesheet">	
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
   
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css"
      rel="stylesheet"
    />
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	
	<!-- DataTables CSS -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	
	<!-- FullCalendar CSS -->
	<link href="assets/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	
 <!-- jQuery -->
 <script src="assets/js/jquery.js"></script>	
    <!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
  <script src="assets/js/isotope.pkgd.min.js"></script> 
 
  <meta name="theme-color" content="#7952b3">
<style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

<link href="assets/css/signin.css" rel="stylesheet">
    
  </head>

  <body class="img-responsive">
    
 

  <div class="intro-header img-responsive">
    <div class="container">

      <div class="row">
        <div class="col-lg-5">
          <div class="intro-message">
            <h1 style="color:#515A5A"><i class=""  aria-hidden="true"></i> Servicios Generales</h1>
            <h3 style="color:#283747">Editar Préstamo</h3>
            <hr class="intro-divider">
            <div class="form-group">
          </div>                       
          </div>

        </div>
      
        
      

        <main class="form-signin">
          <!-- Button para abrir el modal para agregar usuario -->
         
          <div class="row" style="position:relative;">
        <div class="container">
			<a href="agenda"><button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#type">
         Ir a agenda
							</button></a>
              </div> 
                   
              <div >
                <br>
        <h5 style="background-color: black;color:white;padding:5px;text-align:center;border-radius:5px;">Folio 0001</h5>
<form>
<div class="form-floating">
<input type="text" class="form-control" id="floatingInput" name="solicitante" placeholder="Solicitante" required>
<label style="color:black;" for="floatingInput">Solicitante</label>
</div>
<div class="form-floating">
<select name='title' class="form-control form-select input-md" required>
																
																<option value='' >Seleccionar vehiculo</option>
																	
																	<option value='Patrimonio'>Tida</option>
																	

																																</select>
                                                                <label style="color:black;" for="floatingInput">Vehiculo</label>
                                                                </div>

<div class="form-floating">
<input type="text" class="form-control" id="floatingPassword" name="telefono" placeholder="Telefono de contacto" required>
<label style="color:black;" for="floatingPassword">Telefono de contacto</label>
</div>

<div class="form-floating">
<input type="datetime-local" class="form-control" id="floatingInput" name="fecha_inicio" placeholder="Fecha inicial" required>
<label style="color:black;" for="floatingInput">Fecha inicial</label>
</div>

<div class="form-floating">
<input type="datetime-local" class="form-control" id="floatingInput" name="fecha_fin" placeholder="Fecha final"  required>
<label style="color:black;" for="floatingInput">Fecha final</label>
</div>

<div class="form-floating">
<input type="number" min="1" max="20" class="form-control" id="floatingInput" name="num_personas" placeholder="Num. personas">
<label style="color:black;" for="floatingInput">Num. personas</label>
</div>

<div class="form-floating">
<input type="text" class="form-control" id="floatingPassword" name="nombres_personas" placeholder="Nombres de las personas">
<label style="color:black;" for="floatingPassword">Nombres de las personas</label>
</div>

<div class="form-floating">
<input type="text" class="form-control" id="floatingPassword" name="domicilio" placeholder="Domicilio" required>
<label style="color:black;" for="floatingPassword">Domicilio</label>
</div>



<div class="form-floating">
<input type="text" class="form-control" id="floatingPassword" name="descripcion" placeholder="Descripción">
<label style="color:black;" for="floatingPassword">Descripción</label>
</div>

<button class="w-100 btn btn-lg btn-primary" name="editar" id="editar" type="submit">Editar</button>
</form>
</div><!--div col form-->
</main>

</div><!--div row-->
      </div>
    </div>
    <!-- /.container -->
   
  </div>

 
  </body>

  </html>