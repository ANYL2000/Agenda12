<?php
//algoritmo para borrar prestamo

?>